package com.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main2 {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<Employee>();
		
		Employee e1 = new Employee(103,"Kumar");
		Employee e2 = new Employee(112,"Anil");
		Employee e3 = new Employee(107,"Ramesh");
		Employee e4 = new Employee(109,"Ganesh");
		Employee e5 = new Employee(105,"Vidya");
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		for(int i=0; i<empList.size(); i++){
			
			Employee e = empList.get(i);
			System.out.println(e);
		}
		
		Collections.sort(empList, new NameComparator());
		
		System.out.println("----------------------------------");
		System.out.println("After sorting");
		
		for(int i=0; i<empList.size(); i++){
			
			Employee e = empList.get(i);
			System.out.println(e);
		}
	}

}
