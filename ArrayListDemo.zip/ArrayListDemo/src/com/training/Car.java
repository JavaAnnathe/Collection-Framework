package com.training;

public class Car implements Comparable<Car>{
	
	private String brand;

	public Car(String brand) {
		
		this.brand = brand;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Car [brand=" + brand + "]";
	}

	@Override
	public int compareTo(Car o) {
		// TODO Auto-generated method stub
		return this.brand.compareToIgnoreCase(o.brand);
	}

	
	
	

}
