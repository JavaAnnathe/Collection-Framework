package com.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car c1 = new Car("Honda");
		Car c2 = new Car("Maruti");
		Car c3 = new Car("Hyundai");
		Car c4 = new Car("Audi");
		Car c5 = new Car("Benz");
		
		List carList  = new ArrayList();
		carList.add(c1);
		carList.add(c2);
		carList.add(c3);
		carList.add(c4);
		carList.add(c5);
		
		for(int i=0; i<carList.size(); i++){
			Car c = (Car)carList.get(i);
			System.out.println(c);
		}
		
		Collections.sort(carList);
		
		System.out.println("----------------------------------");
		System.out.println("After sorting");
		
		for(int i=0; i<carList.size(); i++){
			Car c = (Car)carList.get(i);
			System.out.println(c);
		}
		
		
	}

}
