package com.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		List<Integer> carSales = new ArrayList<Integer>();
		
		
		carSales.add(1200);
		carSales.add(1500);
		carSales.add(800);
		carSales.add(1700);
		carSales.add(300);
		carSales.add(5, 3500);
		
		System.out.println("Car sales at index 3:"+carSales.get(3));
	
		
		for(int i:carSales){
			
			System.out.println("Car sales:"+i);
		}
	
		Collections.sort(carSales);
		System.out.println("----------------------------------");
		System.out.println("After sorting");
		for(int i:carSales){
			
			System.out.println("Car sales:"+i);
		}
	}

}
