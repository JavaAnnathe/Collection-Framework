package com.training;

import java.util.HashSet;
import java.util.Set;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<Employee> empSet = new HashSet<Employee>();
		
		Employee e1 = new Employee(102,"Kumar");
		Employee e2 = new Employee(103,"Ravi");
		Employee e3 = new Employee(105,"Magesh");
		Employee e4 = new Employee(102,"Kumar");
		
		
		
		
		boolean[] b = new boolean[4];
		
		b[0] = empSet.add(e1);
		b[1] = empSet.add(e2);
		b[2] = empSet.add(e3);
		b[3] = empSet.add(e4);
		
		for(boolean r:b){
			System.out.println(r);
		}
		System.out.println("Inside set:"+empSet);
	}

}
