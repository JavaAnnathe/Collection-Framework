package com.training;

import java.util.HashSet;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		
		Set myNum = new HashSet();
		
		boolean[] b = new boolean[5];
		
		b[0]=myNum.add("B");
		b[1]=myNum.add("A");
		b[2]=myNum.add("B");
		b[3]=myNum.add("D");
		b[4]=myNum.add("C");
		
		for(boolean r:b){
			System.out.println(r);
		}
		
		System.out.println("Inside set:"+myNum);
	}

}
