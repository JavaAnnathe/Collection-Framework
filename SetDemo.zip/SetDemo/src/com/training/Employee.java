package com.training;

import java.util.Random;

public class Employee {
	
	private Integer id;
	
	private String name;

	public Employee(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

	@Override
	public int hashCode() {
		int result= id * new Random().nextInt();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		Employee other = (Employee) obj;
		
		if((this.id.equals(other.id))&& this.name.equals(other.name)){
		
		return true;
	}
		else{
			
			return false;
		}
	
	

}
}