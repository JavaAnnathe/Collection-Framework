package com.training;

import java.util.HashMap;
import java.util.Map;

public class Main1 {

	public static void main(String[] args) {
		
		Map<Employee,Integer> employeeMap = new HashMap<Employee,Integer>();
		
		Employee e1 = new Employee(103,"Kumar");
		Employee e2 = new Employee(112,"Anil");
		Employee e3 = new Employee(107,"Ramesh");
		Employee e4 = new Employee(109,"Ganesh");
		Employee e5 = new Employee(105,"Vidya");
		
		employeeMap.put(e1, 50000);
		employeeMap.put(e2, 70000);
		employeeMap.put(e3, 30000);
		
		Integer salary = employeeMap.get(new Employee(107,"Ramesh"));
		
		System.out.println("Salary of Ramesh:"+employeeMap.get(new Employee(107,"Ramesh")));
		

	}

}
