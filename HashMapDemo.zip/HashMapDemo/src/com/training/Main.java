package com.training;

import java.util.HashMap;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map m = new HashMap();
		
		m.put("Kumar", 80);
		m.put("Raghav", 70);
		m.put("Mohan", 75);
		m.put("Anitha", 85);
		
		System.out.println("Marks scored by Mohan:"+m.get("Mohan"));

	}

}
